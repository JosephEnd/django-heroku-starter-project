// Materialize jQuery characterCounter for textarea
$(document).ready(function() {
  $('textarea#feedbackarea1').characterCounter();
});
